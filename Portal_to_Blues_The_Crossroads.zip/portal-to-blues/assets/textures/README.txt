Drop an optional ground-dirt.jpg texture here (a seamless/tileable dirt or
dust photo works best) to replace the flat procedural ground color. See the
main README.md for details. The game works fine without it.
