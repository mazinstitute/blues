Drop optional sound files here - see the "Optional sound and image files"
section of the main README.md for the exact filenames the game looks for
(plaza-ambient.mp3, ambient-delta.mp3, portal-whoosh.mp3, footstep.mp3, etc).
The game works fine without any of them; it synthesizes its own sound effects.
