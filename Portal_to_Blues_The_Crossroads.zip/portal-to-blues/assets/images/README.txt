Not used by the game itself - a place to keep extra artwork, an icon, or a
printable takeaway sheet if you want to extend the project.
